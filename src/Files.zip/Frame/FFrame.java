package Frame;

import Game.*;
import javax.swing.*;

public class FFrame extends JFrame {
    private final FPanel panel = new FPanel();

    public FFrame (){
        add(panel);
        setTitle("Flappy Bird");
        setSize(500,520);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

