package Frame;

import Game.DPanel;
import Game.FPanel;

import javax.swing.*;

public class DFrame extends JFrame {
    private final DPanel panel = new DPanel();


    public DFrame (){
        add(panel);
        setTitle("Dino Game");
        setSize(800,400);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}