package Game;

import javax.swing.*;
import java.awt.*;

public class Restart extends Objects{
    public Image restart = new ImageIcon("src/Files/restart.png").getImage();

    public Restart(int x, int y, int width, int height){
        super(x, y, width, height);
    }

    public void draw(Graphics g){
        g.drawImage(restart, this.x, this.y, this.width, this.height, null);
    }

    public int move(int velocity, int acceleration){
        return 0;
    }
}
