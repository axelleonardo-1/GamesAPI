package Game;

import javax.swing.*;
import java.awt.*;

public class Instruction extends Objects{
    public Image instruction = new ImageIcon("src/Files/start.png").getImage();

    public Instruction(int x, int y, int width, int height){
        super(x, y, width, height);
    }

    public void draw(Graphics g){
        g.drawImage(instruction, this.x, this.y, this.width, this.height, null);
    }

    public int move(int velocity, int acceleration){
        return 0;
    }

}
