package Game;

import javax.swing.*;
import java.awt.*;

public class Cactus extends Objects{
    public Image cactus1 = new ImageIcon("src/Files/cactus1.png").getImage();
    public Image cactus2 = new ImageIcon("src/Files/cactus2.png").getImage();
    private static Image cactus;

    public Cactus(int x, int y, int width, int height, int cactus) {
        super(x, y, width, height);
        if (cactus == 1)
            this.cactus = cactus1;
        else
            this.cactus = cactus2;

    }

    public void draw(Graphics g){
        g.drawImage(cactus, this.x, this.y, this.width, this.height,null);
    }

    public int move(int velocityX, int acceleration){
        velocityX -= acceleration;
        return velocityX;
    }
}
