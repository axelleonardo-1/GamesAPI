package Game;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.io.IOException;

public class GameLogic extends JPanel {
    protected static boolean startPauseB = false;
    protected static boolean startB = false;
    public boolean gameover;
    public static AudioBackground audio;
    public int characterAcceleration = 5;
    public int score = 0;

    public GameLogic(){
        this.gameover = false;
        setSize(WIDTH,HEIGHT);
        setFocusable(true);

        try {
            audio = new AudioBackground();
        } catch (UnsupportedAudioFileException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (LineUnavailableException e) {
            throw new RuntimeException(e);
        }
    }

    public void start(){
        startB = true;
    }

    public void pause(){
        startPauseB = true;
        audio.pause();
        repaint();
    }



}
