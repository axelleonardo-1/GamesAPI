package Game;

import javax.swing.*;
import java.awt.*;

public class Bird extends Objects{
    private static Image bird;

    public Bird(int x, int y, int width, int height) {
        super(x, y, width, height);
        this.bird = new ImageIcon("src/Files/bird2.png").getImage();

    }

    public void draw(Graphics g){
        g.drawImage(bird, this.x, this.y, this.width, this.height,null);
    }

    public int move(int velocityY, int acceleration){
        velocityY += acceleration;
        return velocityY;
    }
}
