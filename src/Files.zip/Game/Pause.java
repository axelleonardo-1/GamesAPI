package Game;

import javax.swing.*;
import java.awt.*;

public class Pause extends  Objects{
    public Image pause = new ImageIcon("src/Files/pause.png").getImage();

    public Pause(int x, int y, int width, int height){
        super(x, y, width, height);
    }

    public void draw(Graphics g){
        g.drawImage(pause, this.x, this.y, this.width, this.height, null);
    }

    public int move(int velocity, int acceleration){
        return 0;
    }
}
