package Game;

import javax.swing.*;
import java.awt.*;

public class Dinosaur extends Objects{
    private static Image dinosaur;

    public Dinosaur(int x, int y, int width, int height) {
        super(x, y, width, height);
        this.dinosaur = new ImageIcon("src/Files/dinosaur.png").getImage();

    }

    public void draw(Graphics g){
        g.drawImage(dinosaur, this.x, this.y, this.width, this.height,null);
    }

    public int move(int velocityY, int acceleration){
        velocityY -= acceleration;
        return velocityY;
    }

}
