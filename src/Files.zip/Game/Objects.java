package Game;

public abstract class Objects {
    public int x, y, width, height;

    public Objects(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public abstract int move(int velocity, int acceleration);
}
