package Game;

import javax.swing.*;
import java.awt.*;

public class Pipe extends Objects{
    public Image pipe1 = new ImageIcon("src/Files/pipe.png").getImage();
    public Image pipe2 = new ImageIcon("src/Files/pipe2.png").getImage();
    final int PIPEVELOCITY = 5;
    private Image pipe;

    public Pipe(int x, int y, int width, int height, int pipe) {
        super(x, y, width, height);
        if (pipe == 1)
            this.pipe = pipe1;
        else
            this.pipe = pipe2;
    }

    public void draw(Graphics g){
        g.drawImage(this.pipe, this.x, this.y,this.width, this.height, null);
    }

    public int move(int velocityX, int acceleration){
        velocityX -= acceleration;
        return velocityX;
    }
}
