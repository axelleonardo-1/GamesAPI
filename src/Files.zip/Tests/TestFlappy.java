package Tests;
import Frame.*;

public  class TestFlappy{
    public static void main(String[] args) {
        new FFrame();
    }
}
