package Tests;
import Frame.*;

public class TestDinosaur {
    public static void main(String[] args) {
        new DFrame();
    }
}
